Kayla Cinnamon
Professor Plotka
Web Science Systems Development
March 2, 2016

Lab 4

I first started this lab by creating my HTML file and putting in dummy text where I wanted the data to go. After I had my page looking the way I wanted, I started working on the javascript. I edited the get_tweets.php file with my keys and access tokens. I then started working on the angularjs. I only made one controller because I was only planning on getting the tweets. I got the tweets showing up in the log first, before I started placing them into my HTML. Once I knew I was accessing the tweets, I started replacing my dummy text with the tweets. After that, I implemented the search bar. Once I had everything that I wanted on the page, I started tweaking my styling a bit and adding the media queries.

Resources and collaborators:
Rachel Blacker
David Sparkman
Stefan Steenstrup
Justin Etzine

stackoverflow.com
getbootstrap.com
docs.angularjs.org
w3schools.com